package main

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"time"

	"github.com/allen13/tegridy-tokens/pkg/encryption"
	"github.com/allen13/tegridy-tokens/pkg/repository"
	"github.com/allen13/tegridy-tokens/pkg/tokenizer"
	"github.com/aws/aws-lambda-go/lambda"
	"github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/aws/aws-sdk-go-v2/service/kms"
)

// TokenizeRequest represents a single tokenization request
type TokenizeRequest struct {
	Data           string            `json:"data"`
	Format         string            `json:"format,omitempty"`
	Metadata       map[string]string `json:"metadata,omitempty"`
	TTLSeconds     *int64            `json:"ttl_seconds,omitempty"`
	PreserveFormat bool              `json:"preserve_format,omitempty"`
	FormatHint     string            `json:"format_hint,omitempty"`
}

// BatchTokenizeRequest represents the batch tokenization request format
type BatchTokenizeRequest struct {
	Requests []TokenizeRequest `json:"requests"`
}

// BatchDetokenizeRequest represents the batch detokenization request format
type BatchDetokenizeRequest struct {
	Tokens []string `json:"tokens"`
}

// HealthResponse represents the health check response
type HealthResponse struct {
	Status    string `json:"status"`
	Service   string `json:"service"`
	Version   string `json:"version"`
	Timestamp int64  `json:"timestamp"`
}

// DetokenizeResponse represents the detokenization response
type DetokenizeResponse struct {
	Results []string `json:"results"`
	Count   int      `json:"count"`
}

// LambdaRequest represents the main Lambda request structure
// We use json.RawMessage to defer parsing of the data field
type LambdaRequest struct {
	Operation string          `json:"operation"` // "tokenize", "detokenize", "health"
	Data      json.RawMessage `json:"data"`      // Raw JSON that will be parsed based on operation
}

// LambdaResponse represents the main Lambda response structure
type LambdaResponse struct {
	Success bool   `json:"success"`
	Data    any    `json:"data,omitempty"` // This needs to remain any for flexibility
	Error   string `json:"error,omitempty"`
}

// Global tokenizer instance (initialized once per Lambda container)
var tkn tokenizer.Tokenizer

// init initializes the tokenizer once per Lambda container lifecycle
func init() {
	ctx := context.Background()

	// Load AWS configuration
	cfg, err := config.LoadDefaultConfig(ctx)
	if err != nil {
		log.Fatalf("unable to load SDK config: %v", err)
	}

	// Get environment variables
	tableName := os.Getenv("DYNAMODB_TABLE_NAME")
	if tableName == "" {
		log.Fatal("DYNAMODB_TABLE_NAME environment variable is required")
	}

	kmsKeyID := os.Getenv("KMS_KEY_ID")
	if kmsKeyID == "" {
		log.Fatal("KMS_KEY_ID environment variable is required")
	}

	// Create AWS clients
	dynamoClient := dynamodb.NewFromConfig(cfg)
	kmsClient := kms.NewFromConfig(cfg)

	// Create repository
	repo := repository.NewDynamoDBRepository(repository.DynamoDBConfig{
		Client:    dynamoClient,
		TableName: tableName,
		TTLField:  "ttl",
	})

	// Create encryptor with envelope encryption
	enc := encryption.NewKMSEncryptor(encryption.KMSConfig{
		Client:          kmsClient,
		KeyID:           kmsKeyID,
		UseEnvelope:     true,
		CacheDataKeys:   true,
		CacheSize:       50,  // Smaller cache for Lambda
		CacheTTLSeconds: 300, // 5 minutes
	})

	// Create tokenizer with FPT support
	tkn = tokenizer.NewTokenizer(tokenizer.Config{
		Repository:     repo,
		Encryptor:      enc,
		TokenGenerator: &tokenizer.SecureTokenGenerator{Length: 32},
		Workers:        10, // Reasonable for Lambda
		EnableFPT:      true,
		FPTConfig: tokenizer.FPTGeneratorConfig{
			AutoDetect:    true,
			DefaultFormat: tokenizer.FormatNone,
		},
	})

	log.Println("Tokenizer initialized successfully")
}

// handler is the main Lambda handler
func handler(ctx context.Context, request LambdaRequest) (LambdaResponse, error) {
	log.Printf("Processing operation: %s", request.Operation)

	switch request.Operation {
	case "tokenize":
		return handleBatchTokenize(ctx, request.Data)
	case "detokenize":
		return handleBatchDetokenize(ctx, request.Data)
	case "health":
		return handleHealth(ctx)
	default:
		return LambdaResponse{
			Success: false,
			Error:   fmt.Sprintf("Unknown operation: %s", request.Operation),
		}, nil
	}
}

// handleBatchTokenize handles batch tokenization requests
func handleBatchTokenize(ctx context.Context, data json.RawMessage) (LambdaResponse, error) {
	var req BatchTokenizeRequest
	if err := json.Unmarshal(data, &req); err != nil {
		return LambdaResponse{
			Success: false,
			Error:   fmt.Sprintf("Invalid request format. Expected batch format with 'requests' array: %v", err),
		}, nil
	}

	// Validate that we have at least one request
	if len(req.Requests) == 0 {
		return LambdaResponse{
			Success: false,
			Error:   "No requests provided",
		}, nil
	}

	// Convert to internal request format
	tokenRequests := make([]tokenizer.TokenRequest, len(req.Requests))
	for i, r := range req.Requests {
		tokenRequests[i] = tokenizer.TokenRequest{
			Data:           r.Data,
			Format:         r.Format,
			Metadata:       r.Metadata,
			TTLSeconds:     r.TTLSeconds,
			PreserveFormat: r.PreserveFormat,
			FormatHint:     tokenizer.DataFormat(r.FormatHint),
		}
	}

	batchReq := tokenizer.BatchTokenRequest{
		Requests: tokenRequests,
	}

	// Tokenize batch
	resp, err := tkn.TokenizeBatch(ctx, batchReq)
	if err != nil {
		return LambdaResponse{
			Success: false,
			Error:   fmt.Sprintf("Batch tokenization failed: %v", err),
		}, nil
	}

	return LambdaResponse{
		Success: true,
		Data:    resp,
	}, nil
}

// handleBatchDetokenize handles batch detokenization requests
func handleBatchDetokenize(ctx context.Context, data json.RawMessage) (LambdaResponse, error) {
	var req BatchDetokenizeRequest
	if err := json.Unmarshal(data, &req); err != nil {
		return LambdaResponse{
			Success: false,
			Error:   fmt.Sprintf("Invalid request format. Expected batch format with 'tokens' array: %v", err),
		}, nil
	}

	// Validate that we have at least one token
	if len(req.Tokens) == 0 {
		return LambdaResponse{
			Success: false,
			Error:   "No tokens provided",
		}, nil
	}

	// Detokenize batch
	results, err := tkn.DetokenizeBatch(ctx, req.Tokens)
	if err != nil {
		return LambdaResponse{
			Success: false,
			Error:   fmt.Sprintf("Batch detokenization failed: %v", err),
		}, nil
	}

	return LambdaResponse{
		Success: true,
		Data: DetokenizeResponse{
			Results: results,
			Count:   len(results),
		},
	}, nil
}

// handleHealth handles health check requests
func handleHealth(ctx context.Context) (LambdaResponse, error) {
	return LambdaResponse{
		Success: true,
		Data: HealthResponse{
			Status:    "healthy",
			Service:   "tegridy-tokens",
			Version:   "1.0.0",
			Timestamp: time.Now().Unix(),
		},
	}, nil
}

func main() {
	lambda.Start(handler)
}